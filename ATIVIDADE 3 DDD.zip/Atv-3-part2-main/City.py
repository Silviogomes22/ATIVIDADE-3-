class City:
    def __init__(self, ddd: int, name_city: str) -> None:
        self.ddd = ddd
        self.name_city = name_city
