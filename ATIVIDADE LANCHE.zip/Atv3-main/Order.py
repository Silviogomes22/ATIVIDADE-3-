class Order:
    def __init__(self, code: int, quantity: int) -> None:
        self.code = code
        self.quantity = quantity
